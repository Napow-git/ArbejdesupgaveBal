﻿using System.Threading.Channels;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //variabler opgave 1 


            int tal1 = 5; 
            int tal2 = 3;

            Console.WriteLine(tal1);
            Console.WriteLine(tal2);
            Console.WriteLine("\n");

            //variabler opgave 2 


            Console.WriteLine("Tal1 er " + tal1);
            Console.WriteLine("Tal2 er " + tal2);
            Console.WriteLine("\n");
            //variabler opgave 3

            string Navn = "Søren";
            int Alder = 16;
            double Penge = 1234.34;

           Console.WriteLine("Jeg hedder " + Navn +" er " + Alder + " år gammel og har tjent " + Penge + " kr. på at lappe cykkler" );
           Console.WriteLine("\n");

            //variabler opgave 4

            double Kage = 23.56;
            double Øl = 34.67;
            double Pølse = 64.34;

            Console.WriteLine(  "Kage       " + Kage + " \n" +
                                "Øl         " + Øl + " \n" +
                                "Pølse      " + Pølse + " \n");

            //variabler opgave 5

            Console.Write("Intast din Navn: ");
            string MinNavn = Console.ReadLine();
            Console.Write("Intast din alder: ");
            int MinAlder = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Jeg hedder " + MinNavn + " og er " + MinAlder +" år gammel"+ " \n");

            //variabler opgave 6



            Console.Write("Intast arealen af en cirkel: ");
            double r = Convert.ToDouble(Console.ReadLine());
            double Areal = Math.PI * Math.Pow(r, 2);
            Console.Write("\n"+ "Arealen af en cirkel med en radius af "+ r + " er: " +Areal);
        }
    }
}
