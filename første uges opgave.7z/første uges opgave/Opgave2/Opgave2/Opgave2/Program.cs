﻿namespace Opgave2
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //Opgave 1


            int tal = 36;
            string navn = "Napow";
            double højte = 186.5;

            tal = 37;
            navn = "Tchandikou";
            højte = 193.5;


            //Opgave 2

            Console.WriteLine(tal);
            Console.WriteLine(navn);
            Console.WriteLine(højte);

            //Opgave 3

            string op3 = "I dag har vi den 24. December";
            Console.WriteLine(op3);

            //Opgave 4

            double op4_1 = 200.50;
            

            string op4_2 = "Jeg har ";
          

            string op4_3 = "kr. i banken";
       

            Console.WriteLine(op4_2 + op4_1 + op4_3);




        }
    }
}
