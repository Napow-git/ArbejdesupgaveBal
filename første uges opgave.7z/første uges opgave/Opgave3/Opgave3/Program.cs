﻿namespace Opgave3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double ar1 = 2 + 1 * 2;

            Console.WriteLine(ar1);
            double ar2 = (2 + 1) * 2;
            Console.WriteLine(ar2);

            double ar3 = 5 / 2D;
            Console.WriteLine(ar3);

            double ar4 = 8 % 3;
            Console.WriteLine(ar4);

            double ar5 = 1 -5;
            Console.WriteLine(ar5);


        }
    }
}
