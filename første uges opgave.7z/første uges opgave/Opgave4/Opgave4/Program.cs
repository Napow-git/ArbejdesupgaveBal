﻿namespace Opgave4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //opgave 1

            int vari1 = 3; 
            int vari2 = 4; 
            int vari3 = 9;
            int vari_result = vari1 * vari2 - vari3;


            Console.WriteLine(vari_result);

            //opgave 2

            double vari4 = 5.5D;
            double vari5 = 66.67D;
            double vari6 = 10D;
            double vari_result2 = vari4 / vari5 + vari6;

            Console.WriteLine("Kim er: " + Convert.ToInt32((vari_result2)) + " år gammel");
        }
    }
}
