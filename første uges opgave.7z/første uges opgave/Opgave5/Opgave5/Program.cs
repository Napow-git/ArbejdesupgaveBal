﻿namespace Opgave5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool var1  = true;
            bool var2 = false;

         
            
                Console.WriteLine(var1);

            int var1_1 = 17;
            int var1_2 = 12;



            Console.WriteLine(var1_1 > var1_2);




            Console.WriteLine(var1_2 > var1_1);




        }
    }
}
