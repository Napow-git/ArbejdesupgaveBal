﻿using System.Diagnostics;

namespace opgave6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //opgave 1
            /*
                        int tal1 = 36;
                        int tal2 = 64;


                        int talsum = tal1 + tal2;

                        if (talsum > 100)
                        {
                            Console.WriteLine("Summen er større 100!");

                        }
                        else if (talsum < 100)
                        {
                            Console.WriteLine("Summen er mindre en 100");
                        }
                        else 
                        {
                            Console.WriteLine("Summen er 100");
                        }
            */

            // opgave 2

            /*
                        Console.Write("Intast din alder: ");
                        double alder1 = Convert.ToDouble(Console.ReadLine());

                        if (alder1 > 57)

                        {
                            Console.WriteLine("Du er for Gammel");

                        }
                        else 

                        {
                            Console.WriteLine("Du er ikke for Gammel");
                        }
            */
            // opgave 3
            /*
                        Console.Write("Intast din alder: ");
                        double alder2 = Convert.ToDouble(Console.ReadLine());

                        if (alder2 > 60)

                        {
                            Console.WriteLine("Du er for Gammel");

                        }
                        else if (alder2 >= 50 || alder2 <= 60)

                        {
                            Console.WriteLine("Du er hverken for Gammel eller for Ung");

                        }
                        else

                        {
                            Console.WriteLine("Du er ikke for Gammel");
                        }
            */


            //opgave 4

            string name = "Napow";
            string user1 =  "";
            string pass1 = "";

/*
            
            Console.Write($"intast din navn: ");
            name = Console.ReadLine();
            if (name == "Napow")
            {

                Console.Write($"Velkommen {name}: ");
            }
            else 
                
                {
                Console.Write("forkert navn");
            }
*/
            // Opgave 5

            Console.Write($"intast din navn: ");
            user1 = Console.ReadLine();
            Console.Write($"intast din navn: ");
            pass1 = Console.ReadLine();
            if (user1 == "N" && pass1 == "T")

            {
                Console.Write($"Velkommen {name}: ");
                if (user1 != "N")

                {
                    Console.Write("forkert brugernavn");
                }
                else if (pass1 != "T")
                {

                    Console.Write($"forkert kode ");
                }




            }
         



            else

            {
                Console.Write($"Velkommen {name} ");
            }
















        }
    }
}
