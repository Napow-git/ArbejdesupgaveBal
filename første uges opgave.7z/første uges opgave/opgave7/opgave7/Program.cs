﻿namespace opgave7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // opgave 1

            int tal = 1;
            switch (tal) 
            { 

            case 1:
                    if (tal != 4){
                        Console.WriteLine("al");
                    }
                    
                    break;  
            case 2:
                    Console.WriteLine("al");
                    break;
            case 3:
                    Console.WriteLine("al");
                    break;
            case 4:
                    Console.WriteLine("al");
                    break;
            case 5:
                    Console.WriteLine("al");
                    break;
            case 6:
                    Console.WriteLine("al");
                    break;


            }

        }
    }
}
